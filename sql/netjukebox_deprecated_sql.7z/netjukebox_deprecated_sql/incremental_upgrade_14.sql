ALTER TABLE `configuration_session` ADD `sign` VARCHAR( 40 ) NOT NULL default '' AFTER `sid`;

-- --------------------------------------------------------

--
-- Database version
--

UPDATE `configuration_server` SET `value` = '14' WHERE `name` = 'database_version' LIMIT 1;

