ALTER TABLE `track` ADD `audio_bitrate` INT UNSIGNED NOT NULL default '0' AFTER `file_size`;
ALTER TABLE `configuration_users` ADD `access_download` ENUM( 'N', 'Y' ) default 'N' NOT NULL AFTER `access_record`;

TRUNCATE TABLE `track`;
-- Table track has been emptied 


--
-- Database version
--

INSERT INTO configuration_database VALUES (3);
