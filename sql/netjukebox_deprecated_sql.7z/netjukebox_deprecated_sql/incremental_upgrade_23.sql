ALTER TABLE `configuration_block` RENAME `block` ;
ALTER TABLE `configuration_cache` RENAME `cache` ;
ALTER TABLE `configuration_counter` RENAME `counter` ;
ALTER TABLE `configuration_httpq` RENAME `httpq` ;
ALTER TABLE `configuration_server` RENAME `server` ;
ALTER TABLE `configuration_session` RENAME `session` ;
ALTER TABLE `configuration_share` RENAME `share` ;
ALTER TABLE `configuration_user` RENAME `user` ;


-- --------------------------------------------------------

--
-- Database version
--

UPDATE `server` SET `value` = '23' WHERE `name` = 'database_version' LIMIT 1;


