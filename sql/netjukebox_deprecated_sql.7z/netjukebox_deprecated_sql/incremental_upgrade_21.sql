ALTER TABLE `track` ADD `error` VARCHAR( 255 ) NOT NULL default '' AFTER `combined`;
ALTER TABLE `track` ADD INDEX ( `error` );

-- --------------------------------------------------------

--
-- Database version
--

UPDATE `configuration_server` SET `value` = '21' WHERE `name` = 'database_version' LIMIT 1;


