ALTER TABLE `track` ADD `transcoded` TINYINT( 1 ) UNSIGNED NOT NULL default '0' AFTER `track_id`;
ALTER TABLE `track` ADD INDEX ( `transcoded` );

-- --------------------------------------------------------

--
-- Database version
--

UPDATE `configuration_server` SET `value` = '22' WHERE `name` = 'database_version' LIMIT 1;


