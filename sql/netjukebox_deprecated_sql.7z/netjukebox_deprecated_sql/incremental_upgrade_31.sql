TRUNCATE TABLE `track`;
 
-- --------------------------------------------------------

--
-- Database version
--

UPDATE `server` SET `value` = '31' WHERE `name` = 'database_version' LIMIT 1;

