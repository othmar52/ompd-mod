ALTER TABLE `httpq` CHANGE `httpq_name` `player_name` VARCHAR( 255 ) NOT NULL default '';
ALTER TABLE `httpq` CHANGE `httpq_host` `player_host` VARCHAR( 255 ) NOT NULL default '';
ALTER TABLE `httpq` CHANGE `httpq_port` `player_port` SMALLINT( 5 ) UNSIGNED NOT NULL default '0';
ALTER TABLE `httpq` CHANGE `httpq_pass` `player_pass` VARCHAR( 255 ) NOT NULL default '';
ALTER TABLE `httpq` CHANGE `httpq_id` `player_id` INT( 10 ) NOT NULL AUTO_INCREMENT;
ALTER TABLE `httpq` ADD `player_type` TINYINT( 3 ) UNSIGNED NOT NULL default '0' AFTER `player_name`;


ALTER TABLE `httpq` RENAME `player`;

ALTER TABLE `session` CHANGE `httpq_id` `player_id` INT( 10 ) NOT NULL default '1';

-- --------------------------------------------------------

--
-- Database version
--

UPDATE `server` SET `value` = '26' WHERE `name` = 'database_version' LIMIT 1;
