CREATE TABLE `configuration_counter` (
`sid` VARCHAR( 40 ) NOT NULL default '',
`album_id` VARCHAR( 32 ) NOT NULL default '',
`user_id` INT UNSIGNED NOT NULL default '0',
`time` INT UNSIGNED NOT NULL default '0'
) TYPE = MYISAM;

ALTER TABLE `configuration_counter` ADD INDEX ( `sid` );
ALTER TABLE `configuration_counter` ADD INDEX ( `album_id` );
ALTER TABLE `configuration_counter` ADD INDEX ( `user_id` );
ALTER TABLE `configuration_counter` ADD INDEX ( `time` );

DELETE FROM `configuration_server` WHERE `name` = 'session_cleanup_time' LIMIT 1;

-- --------------------------------------------------------

--
-- Database version
--

UPDATE `configuration_server` SET `value` = '17' WHERE `name` = 'database_version' LIMIT 1;
