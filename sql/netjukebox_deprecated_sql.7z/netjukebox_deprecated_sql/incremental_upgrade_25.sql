ALTER TABLE `favorite` ADD INDEX ( `stream` );
UPDATE `server` SET `name` = 'server_seed' WHERE `name` = 'server_secret' LIMIT 1;

-- --------------------------------------------------------

--
-- Database version
--

UPDATE `server` SET `value` = '25' WHERE `name` = 'database_version' LIMIT 1;

