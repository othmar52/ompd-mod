-- phpMyAdmin SQL Dump
-- version 2.6.4-pl4
-- http://www.phpmyadmin.net
-- 
-- 
-- Database: `netjukebox`
-- 

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `album`
-- 

CREATE TABLE `album` (
  `artist` varchar(255) NOT NULL default '',
  `artist_alphabetic` varchar(255) NOT NULL default '',
  `album` varchar(255) NOT NULL default '',
  `year` smallint(4) unsigned default NULL,
  `month` tinyint(2) unsigned default NULL,
  `genre_id` varchar(10) NOT NULL default '',
  `album_add_time` int(10) unsigned NOT NULL default '0',
  `discs` tinyint(3) unsigned NOT NULL default '0',
  `album_id` varchar(11) NOT NULL default '',
  `updated` tinyint(1) unsigned NOT NULL default '0',
  KEY `artist` (`artist`),
  KEY `artist_alphabetic` (`artist_alphabetic`),
  KEY `album` (`album`),
  KEY `year` (`year`,`month`),
  KEY `genre_id` (`genre_id`),
  KEY `album_add_time` (`album_add_time`),
  KEY `album_id` (`album_id`),
  KEY `updated` (`updated`)
) ENGINE=MyISAM;

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `bitmap`
-- 

CREATE TABLE `bitmap` (
  `image50` mediumblob NOT NULL,
  `image100` mediumblob NOT NULL,
  `image200` mediumblob NOT NULL,
  `filesize` bigint(20) unsigned NOT NULL default '0',
  `filemtime` int(10) unsigned NOT NULL default '0',
  `flag` tinyint(3) unsigned NOT NULL default '0',
  `image_front` varchar(255) NOT NULL default '',
  `image_back` varchar(255) NOT NULL default '',
  `album_id` varchar(11) NOT NULL default '',
  `updated` tinyint(1) unsigned NOT NULL default '0',
  KEY `flag` (`flag`),
  KEY `cd_front` (`image_front`),
  KEY `cd_back` (`image_back`),
  KEY `album_id` (`album_id`),
  KEY `updated` (`updated`)
) ENGINE=MyISAM;

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `block`
-- 

CREATE TABLE `block` (
  `ip` varchar(255) NOT NULL default '',
  `failed_counter` tinyint(3) unsigned NOT NULL default '0',
  `block_counter` int(10) unsigned NOT NULL default '0',
  `failed_time` int(10) unsigned NOT NULL default '0',
  `block_time` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`ip`),
  KEY `failed_time` (`failed_time`),
  KEY `block_time` (`block_time`)
) ENGINE=MyISAM;

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `cache`
-- 

CREATE TABLE `cache` (
  `id` varchar(20) NOT NULL default '',
  `profile` int(11) NOT NULL default '0',
  `create_time` int(10) unsigned NOT NULL default '0',
  `idle_time` int(10) unsigned NOT NULL default '0',
  `filesize` bigint(20) unsigned NOT NULL default '0',
  `filemtime` int(10) unsigned NOT NULL default '0',
  `relative_file` varchar(255) NOT NULL default '',
  `updated` tinyint(1) unsigned NOT NULL default '0',
  KEY `id` (`id`),
  KEY `profile` (`profile`),
  KEY `idle_time` (`idle_time`),
  KEY `relative_file` (`relative_file`),
  KEY `updated` (`updated`)
) ENGINE=MyISAM;

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `counter`
-- 

CREATE TABLE `counter` (
  `sid` varchar(40) NOT NULL default '',
  `album_id` varchar(11) NOT NULL default '',
  `user_id` int(10) unsigned NOT NULL default '0',
  `flag` tinyint(3) unsigned NOT NULL default '0',
  `time` int(10) unsigned NOT NULL default '0',
  KEY `sid` (`sid`),
  KEY `album_id` (`album_id`),
  KEY `user_id` (`user_id`),
  KEY `time` (`time`),
  KEY `flag` (`flag`)
) ENGINE=MyISAM;

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `favorite`
-- 

CREATE TABLE `favorite` (
  `name` varchar(255) NOT NULL default '',
  `comment` varchar(255) NOT NULL default '',
  `stream` tinyint(1) unsigned NOT NULL default '0',
  `favorite_id` int(10) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (`favorite_id`),
  KEY `comment` (`comment`),
  KEY `name` (`name`),
  KEY `stream` (`stream`)
) ENGINE=MyISAM;

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `favoriteitem`
-- 

CREATE TABLE `favoriteitem` (
  `track_id` varchar(20) NOT NULL default '',
  `stream_url` varchar(255) NOT NULL default '',
  `position` int(10) unsigned NOT NULL default '0',
  `favorite_id` int(10) unsigned NOT NULL default '0',
  KEY `favorite_id` (`favorite_id`,`position`)
) ENGINE=MyISAM;

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `genre`
-- 

CREATE TABLE `genre` (
  `genre_id` varchar(10) NOT NULL default '',
  `genre` varchar(255) NOT NULL default '',
  KEY `genre` (`genre`),
  KEY `genre_id` (`genre_id`)
) ENGINE=MyISAM;

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `httpq`
-- 

CREATE TABLE `httpq` (
  `httpq_name` varchar(255) NOT NULL default '',
  `httpq_host` varchar(255) NOT NULL default '',
  `httpq_port` smallint(5) unsigned NOT NULL default '4800',
  `httpq_pass` varchar(255) NOT NULL default '',
  `media_share` varchar(255) NOT NULL default '',
  `mute_volume` smallint(5) unsigned NOT NULL default '0',
  `httpq_id` int(10) NOT NULL auto_increment,
  PRIMARY KEY  (`httpq_id`),
  KEY `httpq_name` (`httpq_name`)
) ENGINE=MyISAM;

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `server`
-- 

CREATE TABLE `server` (
  `name` varchar(255) NOT NULL default '',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM;

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `session`
-- 

CREATE TABLE `session` (
  `logged_in` tinyint(1) unsigned NOT NULL default '0',
  `user_id` int(10) unsigned NOT NULL default '0',
  `valid_counter` int(10) unsigned NOT NULL default '0',
  `visit_counter` int(10) unsigned NOT NULL default '0',
  `create_time` int(10) unsigned NOT NULL default '0',
  `idle_time` int(10) unsigned NOT NULL default '0',
  `ip` varchar(255) NOT NULL default '',
  `user_agent` varchar(255) NOT NULL default '',
  `sid` varchar(40) NOT NULL default '',
  `sign` varchar(40) NOT NULL default '',
  `seed` varchar(40) NOT NULL default '',
  `thumbnail_size` tinyint(3) unsigned NOT NULL default '100',
  `stream_id` int(10) NOT NULL default '1',
  `download_id` int(10) NOT NULL default '1',
  `httpq_id` int(10) NOT NULL default '135',
  KEY `user_id` (`user_id`),
  KEY `idle_time` (`idle_time`),
  KEY `sid` (`sid`)
) ENGINE=MyISAM;

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `share`
-- 

CREATE TABLE `share` (
  `sid` varchar(40) NOT NULL default '',
  `album_id` varchar(11) NOT NULL default '',
  `download_id` int(11) NOT NULL default '0',
  `expire_time` int(10) unsigned NOT NULL default '0',
  KEY `album_id` (`album_id`),
  KEY `expire_time` (`expire_time`)
) ENGINE=MyISAM;

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `track`
-- 

CREATE TABLE `track` (
  `artist` varchar(255) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `featuring` varchar(255) NOT NULL default '',
  `relative_file` varchar(255) NOT NULL default '',
  `mime_type` varchar(64) NOT NULL default '',
  `filesize` bigint(20) unsigned NOT NULL default '0',
  `filemtime` int(10) unsigned NOT NULL default '0',
  `miliseconds` int(10) unsigned NOT NULL default '0',
  `audio_bitrate` int(10) unsigned NOT NULL default '0',
  `audio_raw_decoded` int(10) unsigned NOT NULL default '0',
  `audio_bits_per_sample` int(10) unsigned NOT NULL default '0',
  `audio_sample_rate` int(10) unsigned NOT NULL default '0',
  `audio_channels` tinyint(3) unsigned NOT NULL default '0',
  `audio_lossless` tinyint(1) unsigned NOT NULL default '0',
  `audio_dataformat` varchar(64) NOT NULL default '',
  `audio_encoder` varchar(64) NOT NULL default '',
  `audio_profile` varchar(64) NOT NULL default '',
  `video_dataformat` varchar(64) NOT NULL default '',
  `video_codec` varchar(64) NOT NULL default '',
  `video_resolution_x` int(10) unsigned NOT NULL default '0',
  `video_resolution_y` int(10) unsigned NOT NULL default '0',
  `video_framerate` int(10) unsigned NOT NULL default '0',
  `disc` tinyint(3) unsigned NOT NULL default '0',
  `number` smallint(5) unsigned default NULL,
  `combined` smallint(5) unsigned default NULL,
  `error` varchar(255) NOT NULL default '',
  `album_id` varchar(11) NOT NULL default '',
  `track_id` varchar(20) NOT NULL default '',
  `transcoded` tinyint(1) unsigned NOT NULL default '0',
  `updated` tinyint(1) unsigned NOT NULL default '0',
  KEY `artist` (`artist`),
  KEY `title` (`title`),
  KEY `relative_file` (`relative_file`),
  KEY `audio_dataformat` (`audio_dataformat`),
  KEY `video_dataformat` (`video_dataformat`),
  KEY `album_id` (`album_id`,`disc`),
  KEY `track_id` (`track_id`),
  KEY `updated` (`updated`),
  KEY `error` (`error`),
  KEY `transcoded` (`transcoded`)
) ENGINE=MyISAM;

-- --------------------------------------------------------

-- 
-- Tabel structuur voor tabel `user`
-- 

CREATE TABLE `user` (
  `username` varchar(255) NOT NULL default '',
  `password` varchar(40) NOT NULL default '',
  `seed` varchar(40) NOT NULL default '',
  `access_media` tinyint(1) unsigned NOT NULL default '0',
  `access_favorite` tinyint(1) unsigned NOT NULL default '0',
  `access_playlist` tinyint(1) unsigned NOT NULL default '0',
  `access_play` tinyint(1) unsigned NOT NULL default '0',
  `access_add` tinyint(1) unsigned NOT NULL default '0',
  `access_stream` tinyint(1) unsigned NOT NULL default '0',
  `access_download` tinyint(1) unsigned NOT NULL default '0',
  `access_cover` tinyint(1) unsigned NOT NULL default '0',
  `access_record` tinyint(1) unsigned NOT NULL default '0',
  `access_config` tinyint(1) unsigned NOT NULL default '0',
  `user_id` int(10) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (`user_id`),
  KEY `username` (`username`)
) ENGINE=MyISAM;

-- --------------------------------------------------------

--
-- Genre example
-- 

INSERT INTO genre VALUES ('a', 'Pop');
INSERT INTO genre VALUES ('aa', 'Rock');
INSERT INTO genre VALUES ('ab', 'Alternative');
INSERT INTO genre VALUES ('b', 'Soul');
INSERT INTO genre VALUES ('ba', 'R&B');
INSERT INTO genre VALUES ('c', 'Dance');
INSERT INTO genre VALUES ('ca', 'Triphop');
INSERT INTO genre VALUES ('cb', 'Rap & Hiphop');
INSERT INTO genre VALUES ('cc', 'Ambient');
INSERT INTO genre VALUES ('d', 'Roots');
INSERT INTO genre VALUES ('da', 'World');
INSERT INTO genre VALUES ('db', 'Folk');
INSERT INTO genre VALUES ('dc', 'Blues');
INSERT INTO genre VALUES ('e', 'Jazz');
INSERT INTO genre VALUES ('f', 'Classic');
INSERT INTO genre VALUES ('g', 'Cabaret');
INSERT INTO genre VALUES ('h', 'Video');
INSERT INTO genre VALUES ('de', 'Country');
INSERT INTO genre VALUES ('df', 'Regea');
INSERT INTO genre VALUES ('i', 'Soundtrack');

-- --------------------------------------------------------

-- 
-- Default users
--

INSERT INTO `user` VALUES ('admin', '9e0de90fc1e0f62350a6d115dae3fde63ef0c1af', 'HfPjzxjnz-wnVMEe728BnK*2Mmq*Gxi4oQCgwZv8', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0);
INSERT INTO `user` VALUES ('anonymous', '98bb99347a862d2a0abc9600cef95c28711eacf6', 'RQj*oK*kux9QGs*HOyEDAcKDDsEVZsdMNWP6EbYw', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Database version
--

INSERT INTO `server` VALUES ('database_version', '25');
