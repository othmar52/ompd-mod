ALTER TABLE `bitmap` CHANGE `filesize` `filesize` BIGINT UNSIGNED NOT NULL default '0';
ALTER TABLE `cache` CHANGE `filesize` `filesize` BIGINT UNSIGNED NOT NULL default '0';
ALTER TABLE `track` CHANGE `filesize` `filesize` BIGINT UNSIGNED NOT NULL default '0';

TRUNCATE TABLE `share`;
ALTER TABLE `share` CHANGE `sign` `sid` VARCHAR( 40 ) NOT NULL default '';

-- --------------------------------------------------------

--
-- Database version
--

UPDATE `server` SET `value` = '24' WHERE `name` = 'database_version' LIMIT 1;




