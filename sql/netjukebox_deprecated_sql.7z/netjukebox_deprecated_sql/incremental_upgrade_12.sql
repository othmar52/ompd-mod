TRUNCATE TABLE `track`;
ALTER TABLE `track` ADD `audio_lossless` TINYINT( 1 ) UNSIGNED default '0' NOT NULL AFTER `audio_channels`;

-- --------------------------------------------------------

CREATE TABLE `configuration_block` (
  `ip` varchar(255) NOT NULL default '',
  `failed_counter` int(10) unsigned NOT NULL default '0',
  `failed_time` int(10) unsigned NOT NULL default '0',
  `block_time` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`ip`)
) TYPE=MyISAM;

-- --------------------------------------------------------

ALTER TABLE `configuration_httpq` CHANGE `name` `httpq_name` VARCHAR( 255 ) NOT NULL default '';

-- --------------------------------------------------------

CREATE TABLE `configuration_server` (
  `name` varchar(255) NOT NULL default '',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`name`)
) TYPE=MyISAM;

-- --------------------------------------------------------

TRUNCATE TABLE `configuration_session`;

ALTER TABLE `configuration_session` DROP `login_time`;
ALTER TABLE `configuration_session` DROP `session_id`;
ALTER TABLE `configuration_session` DROP `secret`;
ALTER TABLE `configuration_session` CHANGE `seed` `seed` VARCHAR( 40 ) NOT NULL default '';
ALTER TABLE `configuration_session` ADD `download_id` INT( 10 ) NOT NULL default '-1' AFTER `stream_id`;

-- --------------------------------------------------------

ALTER TABLE `configuration_users` RENAME `configuration_user`;
TRUNCATE TABLE `configuration_user`;

ALTER TABLE `configuration_user` CHANGE `password` `password` VARCHAR( 40 ) NOT NULL default '';
ALTER TABLE `configuration_user` ADD `seed` VARCHAR( 40 ) NOT NULL default '' AFTER `password`;

-- --------------------------------------------------------

-- 
-- Default users
--

INSERT INTO `configuration_user` VALUES ('admin', '85a9be1d4dec73f69de3dbc53f4f1c49f05830df', 'f78e6440a54cf4f0a32d679d817e32560728d6b0', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, NULL);
INSERT INTO `configuration_user` VALUES ('anonymous', 'a4d2e8f559daa96fcaacfbfe8345ed7544755571', 'cf5dca13c84844cbd235fd085e26cb44705ea589', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Database version
--

DROP TABLE `configuration_database`;
INSERT INTO `configuration_server` VALUES ('database_version', '12');
