CREATE TABLE `configuration_share` (
`key1` VARCHAR( 20 ) NOT NULL default '',
`key2` VARCHAR( 20 ) NOT NULL default '',
`album_id` VARCHAR( 32 ) NOT NULL default '',
`download_id` INT NOT NULL default '0',
`expire_time` INT UNSIGNED NOT NULL default '0' 
) TYPE = MYISAM;

ALTER TABLE `configuration_share` ADD INDEX ( `key1` );
ALTER TABLE `configuration_share` ADD INDEX ( `key2` );
ALTER TABLE `configuration_share` ADD INDEX ( `album_id` );
ALTER TABLE `configuration_share` ADD INDEX ( `expire_time` );

-- --------------------------------------------------------

--
-- Database version
--

UPDATE `configuration_server` SET `value` = '18' WHERE `name` = 'database_version' LIMIT 1;




