DROP TABLE `block`;


ALTER TABLE `country`  CHANGE COLUMN `code` `code` SMALLINT(6) UNSIGNED NOT NULL default '0';


ALTER TABLE `session` CHANGE `valid_counter` `hit_counter` INT( 10 ) UNSIGNED NOT NULL DEFAULT '0';
ALTER TABLE `session` ADD `pre_login_time` BIGINT UNSIGNED DEFAULT '0' NOT NULL AFTER `create_time`;
ALTER TABLE `session` ADD `login_time` INT UNSIGNED DEFAULT '0' NOT NULL AFTER `pre_login_time`;
ALTER TABLE `session` ADD `thumbnail` TINYINT( 1 ) UNSIGNED DEFAULT '0' NOT NULL AFTER `skin`;
ALTER TABLE `session` ADD `random_blacklist` VARCHAR( 255 ) DEFAULT '' NOT NULL AFTER `skin`;
ALTER TABLE `session` ADD INDEX `ip` ( `ip` , `pre_login_time` );

ALTER TABLE `user` ADD `version` TINYINT( 1 ) UNSIGNED DEFAULT '0' NOT NULL AFTER `seed`;


-- --------------------------------------------------------

--
-- Database version
--

UPDATE `server` SET `value` = '32' WHERE `name` = 'database_version' LIMIT 1;