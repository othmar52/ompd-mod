UPDATE country SET iso = LOWER(iso);
DELETE FROM `server` WHERE `name` = 'counter_start_time';



-- --------------------------------------------------------

--
-- Database version
--

UPDATE `server` SET `value` = '29' WHERE `name` = 'database_version' LIMIT 1;
