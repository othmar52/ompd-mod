ALTER TABLE `user` ADD `access_statistics` TINYINT( 1 ) UNSIGNED default '0' NOT NULL AFTER `access_media`;
ALTER TABLE `user` CHANGE `access_config` `access_admin` TINYINT( 1 ) UNSIGNED NOT NULL default '0';

-- --------------------------------------------------------

--
-- Database version
--

UPDATE `server` SET `value` = '30' WHERE `name` = 'database_version' LIMIT 1;
