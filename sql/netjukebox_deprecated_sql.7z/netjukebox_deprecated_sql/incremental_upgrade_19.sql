-- --------------------------------------------------------

--
-- update counter
--

ALTER TABLE `album` DROP `counter;
ALTER TABLE `album` DROP `counter_update_time`;
ALTER TABLE `configuration_counter` ADD `flag` TINYINT UNSIGNED default '0' NOT NULL AFTER `user_id` ;
ALTER TABLE `configuration_counter` ADD INDEX ( `flag` ) ;

-- --------------------------------------------------------

--
-- add configuration_cache
--

CREATE TABLE `configuration_cache` (
`id` VARCHAR( 20 ) NOT NULL default '',
`profile` INT NOT NULL default '0',
`create_time` INT UNSIGNED NOT NULL default '0',
`idle_time` INT UNSIGNED NOT NULL default '0',
`filesize` INT UNSIGNED NOT NULL default '0',
`filemtime` INT UNSIGNED NOT NULL default '0',
`relative_file` VARCHAR( 255 ) NOT NULL default '',
`updated` TINYINT( 1 ) UNSIGNED NOT NULL default '0' 
) TYPE = MYISAM;
ALTER TABLE `configuration_cache` ADD INDEX ( `id` );
ALTER TABLE `configuration_cache` ADD INDEX ( `profile` );
ALTER TABLE `configuration_cache` ADD INDEX ( `idle_time` );
ALTER TABLE `configuration_cache` ADD INDEX ( `relative_file` );
ALTER TABLE `configuration_cache` ADD INDEX ( `updated` );

-- --------------------------------------------------------

--
-- update configuration_share
--

TRUNCATE TABLE `configuration_share`;
ALTER TABLE `configuration_share` DROP `key1`;
ALTER TABLE `configuration_share` DROP `key2`;
ALTER TABLE `configuration_share` ADD `sign` VARCHAR( 40 ) NOT NULL default '' FIRST;

-- --------------------------------------------------------

--
-- update track_id and album_id lenght
--

ALTER TABLE `album` CHANGE `album_id` `album_id` VARCHAR( 11 ) NOT NULL default '';
ALTER TABLE `bitmap` CHANGE `album_id` `album_id` VARCHAR( 11 ) NOT NULL default '';
ALTER TABLE `configuration_counter` CHANGE `album_id` `album_id` VARCHAR( 11 ) NOT NULL default '';
ALTER TABLE `configuration_share` CHANGE `album_id` `album_id` VARCHAR( 11 ) NOT NULL default '';
ALTER TABLE `favoritesitems` CHANGE `track_id` `track_id` VARCHAR( 20 ) NOT NULL default '';
ALTER TABLE `track` CHANGE `album_id` `album_id` VARCHAR( 11 ) NOT NULL default '';
ALTER TABLE `track` CHANGE `track_id` `track_id` VARCHAR( 20 ) NOT NULL default '';

-- --------------------------------------------------------

--
-- update/add disc and track number
--

ALTER TABLE `album` CHANGE `cds` `discs` TINYINT( 3 ) UNSIGNED NOT NULL default '0' ;
ALTER TABLE `track` CHANGE `cd` `disc` TINYINT( 3 ) UNSIGNED NOT NULL default '0' ;
ALTER TABLE `track` ADD `number` SMALLINT UNSIGNED default NULL AFTER `disc` ;
ALTER TABLE `track` ADD `combined` SMALLINT UNSIGNED default NULL AFTER `number` ;

TRUNCATE TABLE `track`;

-- --------------------------------------------------------

--
-- rename favorites to favorite
--

ALTER TABLE `configuration_user` CHANGE `access_favorites` `access_favorite` TINYINT( 1 ) UNSIGNED NOT NULL default '0';
RENAME TABLE `favorites` TO `favorite`;
RENAME TABLE `favoritesitems` TO `favoriteitem`;
ALTER TABLE `favorite` CHANGE `favorites_id` `favorite_id` INT( 10 ) UNSIGNED NOT NULL AUTO_INCREMENT;
ALTER TABLE `favoriteitem` CHANGE `favorites_id` `favorite_id` INT( 10 ) UNSIGNED NOT NULL default '0';

-- --------------------------------------------------------

--
-- Database version
--

UPDATE `configuration_server` SET `value` = '19' WHERE `name` = 'database_version' LIMIT 1;

