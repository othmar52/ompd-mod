TRUNCATE TABLE `configuration_block`;
ALTER TABLE `configuration_block` CHANGE `failed_counter` `failed_counter` TINYINT UNSIGNED NOT NULL default '0';
ALTER TABLE `configuration_block` ADD `block_counter` INT UNSIGNED default '0' NOT NULL AFTER `failed_counter` ;

ALTER TABLE `configuration_session` DROP `failed_counter`;

-- --------------------------------------------------------

--
-- Database version
--

UPDATE `configuration_server` SET `value` = '15' WHERE `name` = 'database_version' LIMIT 1;


 

