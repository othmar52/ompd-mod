ALTER TABLE `track` CHANGE `playtime_miliseconds` `miliseconds` INT( 10 ) UNSIGNED NOT NULL default '0';
ALTER TABLE `track` DROP `playtime`;

-- --------------------------------------------------------

--
-- Database version
--

UPDATE `configuration_server` SET `value` = '20' WHERE `name` = 'database_version' LIMIT 1;


