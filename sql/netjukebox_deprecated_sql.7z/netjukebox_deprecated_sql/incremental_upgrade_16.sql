ALTER TABLE `bitmap` CHANGE `cd_front` `image_front` VARCHAR( 255 ) NOT NULL default '';
ALTER TABLE `bitmap` CHANGE `cd_back` `image_back` VARCHAR( 255 ) NOT NULL default '';

-- --------------------------------------------------------

--
-- Database version
--

UPDATE `configuration_server` SET `value` = '16' WHERE `name` = 'database_version' LIMIT 1;


 

