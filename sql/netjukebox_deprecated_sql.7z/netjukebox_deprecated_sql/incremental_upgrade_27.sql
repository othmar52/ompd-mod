ALTER TABLE `session` ADD `skin` VARCHAR( 255 ) default 'Classic' NOT NULL AFTER `seed`;

TRUNCATE TABLE `bitmap`;
ALTER TABLE `bitmap` ADD `image_front_width` INT UNSIGNED default '0' NOT NULL AFTER `flag`;
ALTER TABLE `bitmap` ADD `image_front_height` INT UNSIGNED default '0' NOT NULL AFTER `image_front_width`;



-- --------------------------------------------------------

--
-- Database version
--

UPDATE `server` SET `value` = '27' WHERE `name` = 'database_version' LIMIT 1;
