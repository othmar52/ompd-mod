-- --------------------------------------------------------

--
-- album
--

ALTER TABLE `album` ADD INDEX ( `counter` );
ALTER TABLE `album` ADD INDEX ( `album_add_time` );

-- --------------------------------------------------------

--
-- bitmap
--

UPDATE bitmap SET flag = 9 WHERE flag = 1;
UPDATE bitmap SET flag = 1 WHERE flag = 2;
UPDATE bitmap SET flag = 2 WHERE flag = 3;
UPDATE bitmap SET flag = 3 WHERE flag = 9;
ALTER TABLE `bitmap` ADD `filesize` INT UNSIGNED default '0' NOT NULL AFTER `image200`;
ALTER TABLE `bitmap` DROP INDEX `filemtime`;
ALTER TABLE `bitmap` ADD INDEX ( `updated` );

-- --------------------------------------------------------

--
-- configuration_block
--

ALTER TABLE `configuration_block` ADD INDEX ( `failed_time` );
ALTER TABLE `configuration_block` ADD INDEX ( `block_time` );

-- --------------------------------------------------------

--
-- configuration_httpq
--

ALTER TABLE `configuration_httpq` ADD `mute_volume` SMALLINT( 5 ) UNSIGNED NOT NULL default '0' AFTER `media_share`;
ALTER TABLE `configuration_httpq` DROP INDEX `name`;
ALTER TABLE `configuration_httpq` ADD INDEX ( `httpq_name` );

-- --------------------------------------------------------

--
--  configuration_server
--

INSERT INTO `configuration_server` ( `name` , `value` ) 
VALUES ( 'session_cleanup_time', '0' );

-- --------------------------------------------------------

--
--  configuration_user
--

ALTER TABLE `configuration_user` CHANGE `access_browse` `access_media` TINYINT( 1 ) UNSIGNED NOT NULL default '0';

-- --------------------------------------------------------

--
--  track
--

TRUNCATE TABLE `track`;
ALTER TABLE `track` DROP `file_size`;
ALTER TABLE `track` ADD `mime_type` VARCHAR( 64 ) NOT NULL default '' AFTER `relative_file`;
ALTER TABLE `track` ADD `filesize` INT UNSIGNED NOT NULL default '0' AFTER `mime_type`;
ALTER TABLE `track` DROP INDEX `cd`;

-- --------------------------------------------------------

--
-- Database version
--

UPDATE `configuration_server` SET `value` = '13' WHERE `name` = 'database_version' LIMIT 1;
